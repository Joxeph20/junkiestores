$('.login').addClass('active')
$('.register').click ( function(){
    $('#login-page').hide(500)
    $('#register-page').show(500) 
    $('.register').addClass('active')
    $('.login').removeClass('active');
    $('.loader, .spinner').show(1).fadeOut(1000)
});


$('.login').click ( function(){
    $('#login-page').show(500)
    $('#register-page').hide(500)
    $('.login').addClass('active')
    $('.register').removeClass('active')
    $('.loader, .spinner').show(1).fadeOut(1000)
});
$(window).on("load", function(){
    $(".loader").fadeOut(3000)
    $(".spinner").fadeOut(4000)
});
var b = document.getElementById("pr");
function products(){
        b.style.right ="198px";
        b.style.width = "70px"
    }
    var s = document.getElementById("pr");
function sign(){
        b.style.right ="285px";
        b.style.width = "65px"
    }
    var a = document.getElementById("pr");
function home(){
        b.style.right ="365px";
        b.style.width = "65px"
    }
    var c = document.getElementById("pr");
    function contact(){
            b.style.right ="84px";
            b.style.width = "90px"
        }
        var u = document.getElementById("pr");
        function about(){
                b.style.right ="8px";
                b.style.width = "55px"
            }
$('.home').click (function(){
    $('.homepage').show()
    $('.block').hide()
    $('.product').hide()
    $('.contact-us').hide()
    $('.loader, .spinner').show(1).fadeOut(1000)
});
$('.sign').click (function(){
    $('.homepage').hide()
    $('.block').show()
    $('.product').hide()
    $('.contact-us').hide()
    $('.loader, .spinner').show(1).fadeOut(1000)
});
$('.products').click (function(){
    $('.homepage').hide()
    $('.block').hide()
    $('.product').show()
    $('.contact-us').hide()
    $('.loader, .spinner').show(1).fadeOut(1000)
    
});
$('.contact').click (function(){
    $('.homepage').hide()
    $('.block').hide()
    $('.product').hide()
    $('.contact-us').show()
    $('.loader, .spinner').show(1).fadeOut(1000)
    
});
$('.about').click (function(){
    $('.homepage').hide()
    $('.block').hide()
    $('.product').hide()
    $('.contact-us').hide()
    $('.loader, .spinner').show(1).fadeOut(1000)
    
});
