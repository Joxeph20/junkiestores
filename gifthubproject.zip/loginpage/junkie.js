
$('.register').addClass('active')
$('.register').click ( function(){
    $('#login-page').hide(500)
    $('#register-page').show(500) 
    $('.register').addClass('active')
    $('.login').removeClass('active');
    $('.loader, .spinner').show(1).fadeOut(1000)
});
$('.accept').click( function(){
    $('.cookie-container').fadeOut(200)
})
$('.login').show()
$('.register').show()
$('.login').click ( function(){
    $('#login-page').show(500)
    $('#register-page').hide(500)
    $('.login').addClass('active')
    $('.register').removeClass('active')
    $('.loader, .spinner').show(1).fadeOut(1000)
});
$(window).on("load", function(){
    $(".loader").fadeOut(3000)
    $(".spinner").fadeOut(4000)
});
    $('.search .fal').click (function(){
        $('.search').fadeOut(500)
    })
    $(' .search-btm .fas').click (function() {
        $('.search').fadeIn(100)
    })
$('.home').click (function(){
    $('.homepage').show()
    $('.signin').hide()
    $('.product').hide()
    $('.contact-us').hide()
    $('.loader, .spinner').show(1).fadeOut(1000)
});
$('.contact').click (function(){
    $('.homepage').hide()
    $('.signin').hide()
    $('.product').hide()
    $('.contact-us').show()
    $('.loader, .spinner').show(1).fadeOut(1000)
    
});
$('.about').click (function(){
    $('.homepage').hide()
    $('.signin').hide()
    $('.product').hide()
    $('.contact-us').hide()
    $('.loader, .spinner').show(1).fadeOut(1000)
    
});
$('.brand').click (function(){
    $('.brands').fadeToggle(100)
    $('.color').hide()
    $('.price').hide()
    $('.currency').hide()
})
$('.colors').click (function(){
    $('.color').fadeToggle(100)
    $('.brands').hide()
    $('.price').hide()
    $('.currency').hide()
})
$('.pricerange').click (function(){
    $('.price').fadeToggle(100)
    $('.color').hide()
    $('.brands').hide()
    $('.currency').hide()
})
$('.cur').click (function(){
    $('.currency').fadeToggle(100)
    $('.color').hide()
    $('.price').hide()
    $('.brands').hide()
})
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents1');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
});
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents2');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
});
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents3');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
});
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents4');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
});
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents1(lv)');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
});
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents1(levi)');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
});
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents1(ad)');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
});
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents1(dg)');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
});
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('contents1(nike)');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
}); 
window.addEventListener('mouseup', function(event){
    var box = document.getElementById ('login-box');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
        $('.acct .fas').show(300)
    }
}); 

window.addEventListener('mouseup', function(event){
    var box = document.getElementById('cartbox');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
        $('.cart .far').show(300)
    }
}); 
window.addEventListener('mouseup', function(event){
    var box = document.getElementById('buyblock');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
}); 
window.addEventListener('mouseup', function(event){
    var box = document.getElementById('countries');
    if(event.target != box && event.target.parentNode != box){
        box.style.display= 'none'
    }
}); 
$('.lv').click( function(){
    $('.brand').hide()
    $('.brands').hide()
    $('.lvbrand').show()
    $('.levibrand').hide()
    $('.levisbrands').hide()
    $('.adbrand').hide()
    $('.adbrands').hide()
    $('.dgbrand').hide()
    $('.dgbrands').hide()
    $('.nikebrand').hide()
    $('.nikebrands').hide()
})
$('.lvbrand').click (function(){
    $('.lvbrands').fadeToggle(100)
    $('.color').hide()
    $('.price').hide()
    $('.currency').hide()
})
$('.levi').click( function(){
    $('.brand').hide()
    $('.brands').hide()
    $('.lvbrand').hide()
    $('.lvbrands').hide()
    $('.levibrand').show()
    $('.adbrand').hide()
    $('.adbrands').hide()
    $('.dgbrand').hide()
    $('.dgbrands').hide()
    $('.nikebrand').hide()
    $('.nikebrands').hide()
})
$('.levibrand').click (function(){
    $('.levisbrands').fadeToggle(100)
    $('.color').hide()
    $('.price').hide()
    $('.currency').hide()
})
$('.allbrands').click( function(){
    $('.brand').show()
    $('.categories img').show(100)
    $('.brands').hide()
    $('.lvbrand').hide()
    $('.lvbrands').hide()
    $('.levibrand').hide()
    $('.levisbrands').hide()
    $('.adbrand').hide()
    $('.adbrands').hide()
    $('.dgbrand').hide()
    $('.dgbrands').hide()
    $('.nikebrand').hide()
    $('.nikebrands').hide()
})
$('.ad').click( function(){
    $('.category img').show(100)
    $('.categories .row-2 h4').hide()
    $('.watch-text').hide()
    $('.headwear-text').hide()
    $('.brown').hide()
    $('.black').hide()
    $('.jewelry').hide()
    $('.brand').hide()
    $('.brands').hide()
    $('.lvbrand').hide()
    $('.lvbrands').hide()
    $('.levibrand').hide()
    $('.levisbrands').hide()
    $('.adbrand').show()
    $('.dgbrand').hide()
    $('.dgbrands').hide()
    $('.nikebrand').hide()
    $('.nikebrands').hide()
    $('.loader, .spinner').show(1).fadeOut(1000)
})
$('.adbrand').click (function(){
    $('.adbrands').fadeToggle(100)
    $('.color').hide()
    $('.price').hide()
    $('.currency').hide()
})
$('.dg').click( function(){
    $('.brand').hide()
    $('.brands').hide()
    $('.lvbrand').hide()
    $('.lvbrands').hide()
    $('.levibrand').hide()
    $('.levisbrands').hide()
    $('.adbrand').hide()
    $('.adbrands').hide()
    $('.dgbrand').show()
    $('.nikebrand').hide()
    $('.nikebrands').hide()
})
$('.dgbrand').click (function(){
    $('.dgbrands').fadeToggle(100)
    $('.color').hide()
    $('.price').hide()
    $('.currency').hide()
})
$('.nike').click( function(){
    $('.brand').hide()
    $('.brands').hide()
    $('.lvbrand').hide()
    $('.lvbrands').hide()
    $('.levibrand').hide()
    $('.levisbrands').hide()
    $('.adbrand').hide()
    $('.adbrands').hide()
    $('.dgbrand').hide()
    $('.nikebrand').show()
    $('.nikebrands').hide()
})
$('.nikebrand').click (function(){
    $('.nikebrands').fadeToggle(100)
    $('.color').hide()
    $('.price').hide()
    $('.currency').hide()
})
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 600) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
var m = document.getElementById ("bar");
var q = document.getElementById ("image-view")
function prdt1(){
    m.style.height = "80px";
    m.style.width= "110px";
    m.style.top= "15px";
    q.style.left=" 20%"
}
var n = document.getElementById ("bar");
var q = document.getElementById ("image-view")
function prdt2(){
    m.style.height = "110px";
    m.style.width= "110px";
    m.style.top= "100px";
    q.style.left=" -76%"
}
var n = document.getElementById ("bar");
var q = document.getElementById ("image-view")
function prdt3(){
    m.style.height = "120px";
    m.style.width= "110px";
    m.style.top= "210px";
    q.style.left=" -160%"
}
$('.home-category a').hide()
$('.home-category ').hide()
$('.men-items .fal').click ( function () {
    $('.men-items a').toggle(500)
})
$('.female .fal ').click ( function () {
    $('.female-items a').toggle(500)
})
$('#sign').click (function () {
    $('.home-category ').show()
})
$('.children .fal ').click ( function () {
    $('.children-items a').toggle(500)
})

$('.acct .fas').click (function () {
    $('.login-box').fadeIn(300)
    $('.acct .fas').hide(300)
})
$('.login-box .fal').click( function(){
    $('.login-box').fadeOut(300)
    $('.acct .fas').show(300)
})
function show() {
    
    var x = document.getElementById('pasword');
    var check = document.querySelector ('.checkbox');
    if (pasword.type === "password"){
        pasword.type = "text"
    }
    else {
        pasword.type = "password"
    }
    }
$('.cart .far').click (function () {
    $('.cart-box').fadeIn(400)
    $('.cart .far').hide(300)
})
$('#closecartbox').click (function () {
    $('.cart-box').fadeOut(400)
    $('.cart .far').show(300)
})
$('.exit .fal').click (function () {
    $('.home-category').hide()
})
/*--main icons--*/
$('.us').hide()
$('.cad').hide()
$('.uk-pounds').hide()
$('.uk-euro').hide()
/*--end--*/

$('.country-price').click(function () {
    $('.countries').show()
});
/*--USA--*/
$('.usa').click (function () {
    $('.countries').fadeOut()
    $('.ng').hide()
    $('.cad').hide()
    $('.us').show()
    $('.naira').hide()
    $('.dollars').show()
    $('.usa').hide()
    $('.nigeria').show()
    $('.canada').show()
    $('.canadian').hide()
    $('.euro').hide()
    $('.loader, .spinner').show(1).fadeOut(9000)
})
/*--Nigeria--*/
$('.nigeria').click (function () {
    $('.ng').show()
    $('.cad').hide()
    $('.us').hide()
    $('.nigeria').hide()
    $('.usa').show()
    $('.naira').show()
    $('.dollars').hide()
    $('.canadian').hide()
    $('.euro').hide()
    $('.uk-pounds1').hide()
    $('.loader, .spinner').show(1).fadeOut(9000)
})
/*--currencies--*/
$('.nigeria').hide()
$('.dollars').hide()
$('.canadian').hide()
$('.pounds').hide()
$('.euro').hide()
/*--canada--*/
$('.canada').click (function () {
    $('.ng').hide()
    $('.us').hide()
    $('.naira').hide()
    $('.dollars').hide()
    $('.canadian').show()
    $('.canada').hide()
    $('.usa').show()
    $('.nigeria').show()
    $('.cad').show()
    $('.euro').hide()
    $('.loader, .spinner').show(1).fadeOut(9000)
})
$('.uk-pounds1').click (function () {
    $('.ng').hide()
    $('.us').hide()
    $('.naira').hide()
    $('.dollars').hide()
    $('.canadian').hide()
    $('.canada').show()
    $('.usa').show()
    $('.nigeria').show()
    $('.cad').hide()
    $('.euro').hide()
    $('.pounds').show()
    $('.uk-euro').hide()
    $('.uk-pounds').show()
    $('.uk-pounds1').hide()
    $('.loader, .spinner').show(1).fadeOut(9000)
})
$('.uk-euro1').click (function () {
    $('.ng').hide()
    $('.us').hide()
    $('.naira').hide()
    $('.dollars').hide()
    $('.canadian').hide()
    $('.canada').show()
    $('.usa').show()
    $('.nigeria').show()
    $('.cad').hide()
    $('.euro').show()
    $('.pounds').hide()
    $('.uk-pounds').hide()
    $('.uk-euro').show()
    $('.uk-pounds1').show()
    $('.uk-euro1').hide()
    $('.loader, .spinner').show(1).fadeOut(9000)
})
$('.french').hide()
$('.francias').hide()
$('.product-info button').click (function () {
    $('.buy-block').fadeIn(500)
    $('.product-info button').fadeOut()
})